#include <stdio.h>
#include <wiringPi.h>
#include "In_out.h"

void Write_Latch(unsigned int*ptr){
    unsigned int *gpset0 = ptr+7;   //28
    *gpset0 = (*gpset0) | (0b1<<9); // set pin9 to 1  latch
}

void Write_Clock(unsigned int*ptr){
    unsigned int *gpset0 = ptr+7;   //28
    *gpset0 = (*gpset0) | (0b1<<11); // set pin11 to 1  clock
}

void Clear_Latch(unsigned int* ptr){
    unsigned int *gpclr0 = ptr+10;  //40
    *gpclr0 = (*gpclr0) | (0b1<<9); // set pin9 to 0
}

void Clear_Clock(unsigned int* ptr){
    unsigned int *gpclr0 = ptr+10;  //40
    *gpclr0 = (*gpclr0) | (0b1<<11); // set pin11 to 0
}

void Wait(int T){
    delayMicroseconds(T);
}

int Read_Data(unsigned int* ptr){
    unsigned int *gplev0 = ptr+13;  //54
    if ( !((*gplev0) & (0b1<<10)) ){ // return 0 represents button was pressed
        return 0;
    }
    else{           // this one is normal case, buttons are always high
        return 1;
    }
}