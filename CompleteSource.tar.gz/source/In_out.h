#ifndef In_out
#define In_out


void Write_Latch(unsigned int*ptr);
void Write_Clock(unsigned int*ptr);
void Clear_Latch(unsigned int* ptr);
void Clear_Clock(unsigned int* ptr);
void Wait(int T);
int Read_Data(unsigned int* ptr);



#endif