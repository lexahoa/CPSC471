#ifndef Init_GPIO
#define Init_GPIO

void Init_GPI(int g , unsigned int* ptr, int mode);


#endif