#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "framebuffer.h"
#include "alien.h"
#include <unistd.h>
#include "initGPIO.h"
#include "Init_GPIO.h"
#include "In_out.h"
#include "Read_SNES.h"
#include <pthread.h>
#include "mario.h"
#include "background.h"
#include "bigmario.h"
#include "maps.h"
#include "tree.h"
#include "wall.h"
#include "coin.h"
#include "death.h"
#include "exit.h"
#include "words.h"
#include "time.h"
#include "speed_up.h"

#define Data 10
#define Latch 9
#define Clock 11
void *thread_function(void *ptr);
void change_position(int *ptr);
void change_menu(int *ptr);
void init_map(int theone);
void *timer(void *ptr);
void *move_object_up_down();
void *move_object_left_right();
void reset_player(int key);
void restart();

/* Definitions */
typedef struct
{
	short int color;
	int x, y;
} Pixel;

struct
{
	int x_pos;
	int y_pos;
	int x_width;
	int y_width;
	int current_map;
	int live;
	int time;
	int score;
	int time_flag;
	int speed;
	int upper_bound;
	int lower_bound;
	int recent_time;
	int play_able;
	int decision;
	int should_move;
} player_postion;

struct fbs framebufferstruct;
void drawPixel(Pixel *pixel);
void set_number_color(int number, Pixel **p, int counter);
int flag = 0;
int win_flag = 0;
int lose_flag = 0;
map_instance resume_map;

/* main function */
int main()
{
	/* initialize + get FBS */
	framebufferstruct = initFbInfo();
	// pixel pointers//

	short int *alienPtr = (short int *)background.pixel_data;
	short int *marioPtr = (short int *)mario.pixel_data;
	short int *wallPtr = (short int *)wall.pixel_data;
	short int *treePtr = (short int *)tree.pixel_data;
	short int *coinPtr = (short int *)coin.pixel_data;
	short int *deathPtr = (short int *)death.pixel_data;
	short int *exitPtr = (short int *)exit_color.pixel_data;
	short int *livePtr = (short int *)live.pixel_data;
	short int *timePtr = (short int *)time_w.pixel_data;
	short int *scorePtr = (short int *)score.pixel_data;
	short int *spPtr = (short int *)speed_up.pixel_data;
	short int *titlePtr = (short int *)supermario.pixel_data;
	short int *startPtr = (short int *)start.pixel_data;
	short int *quitPtr = (short int *)Quit.pixel_data;
	short int *selectPtr = (short int *)selection.pixel_data;
	short int *restartPtr = (short int *)re_start.pixel_data;
	short int *losePtr = (short int *)Lose.pixel_data;
	short int *winPtr = (short int *)Win.pixel_data;
	short int *authorPtr = (short int *)author.pixel_data;

	/* initialize a pixel */
	Pixel *pixel;
	pixel = malloc(sizeof(Pixel));

	init_map(0);
	player_postion.should_move = 1;
	int num_counter[32 * 18];
	int special_list[10];
	for (int i = 0; i < 576; i++)
	{
		if (i < 10)
			special_list[i] = 0;
		num_counter[i] = 0;
		resume_map.map[i] = -1;
	}

	int i = 0;
	int m = 0;
	// unsigned int quarter, byte, word;
	printf("Created by: Zhongmin Ma");

	pthread_t pid;
	pthread_t t_id;
	pthread_t m_id;
	pthread_t lf_id;
	pthread_create(&pid, NULL, thread_function, NULL);
	pthread_create(&t_id, NULL, timer, NULL);
	pthread_create(&m_id, NULL, move_object_up_down, NULL);
	pthread_create(&lf_id, NULL, move_object_left_right, NULL);
	while (1)
	{
		if (game_map.special_case == 0)
		{
			if (player_postion.recent_time - player_postion.time > 5)
			{
				game_map.map[game_map.special_y * 32 + game_map.special_x] = 18;
				game_map.special_case = 1;
			}
		}
		for (int y = 0; y < 720; y++) // 30 is the image height    //(1080-720)/2 = 180
		{
			for (int x = 0; x < 1280; x++) // 30 is image width    // (1920-1280)/2 = 320
			{
				int offsite = ((y / 40) * 32) + (x / 40);
				int color_choice = game_map.map[offsite];
				if ((y >= player_postion.y_pos - player_postion.y_width) && (y <= player_postion.y_pos - player_postion.y_width + 15) && (x >= player_postion.x_pos - player_postion.x_width) && (x <= player_postion.x_pos - player_postion.x_width + 15))
				{ // draw mario
					if (color_choice == 4 || color_choice == 9)
						reset_player(1);
					else if (color_choice == 18)
					{
						game_map.map[offsite] = 1;
						player_postion.upper_bound -= 120;
						player_postion.live += 1;
						player_postion.score += 30;
					}
					pixel->color = marioPtr[m];
					pixel->x = x + 320; // only work on 2K screen,
					pixel->y = y + 180; // only work on 2K screen, central the place.
					drawPixel(pixel);
					m++;
					num_counter[offsite] += 1;
				}
				else
				{
					switch (color_choice)
					{
					case 0: // walldd
						pixel->color = wallPtr[0];
						break;
					case 1: // road
						pixel->color = alienPtr[i];
						break;
					case 2: // tree
						pixel->color = treePtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 3: // coin
						pixel->color = coinPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 4: // dead
						pixel->color = deathPtr[0];
						break;
					case 5: // fin
						pixel->color = exitPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 6: // live    special
						pixel->color = livePtr[special_list[0]];
						special_list[0] += 1;
						break;
					case 7: // score   special
						pixel->color = scorePtr[special_list[1]];
						special_list[1] += 1;
						break;
					case 8: // time    special
						pixel->color = timePtr[special_list[2]];
						special_list[2] += 1;
						break;
					case 9:
						pixel->color = deathPtr[0];
						break;
					case 10: // live    less than 10
						set_number_color(player_postion.live, &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 11: // score
						set_number_color((player_postion.score / 100), &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 12:
						set_number_color(((player_postion.score % 100) / 10), &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 13:
						set_number_color((player_postion.score % 10), &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 14: // time
						set_number_color((player_postion.time / 10), &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 15:
						set_number_color((player_postion.time % 10), &pixel, num_counter[offsite]);
						num_counter[offsite] += 1;
						break;
					case 16:
						pixel->color = exitPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 17: // hidden door
						pixel->color = treePtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 18:
						pixel->color = spPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 19:
						pixel->color = wallPtr[0];
						num_counter[offsite] += 1;
						break;
					case 20:
						pixel->color = exitPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 21:
						pixel->color = titlePtr[special_list[3]];
						special_list[3] += 1;
						break;
					case 22:
						pixel->color = startPtr[special_list[4]];
						special_list[4] += 1;
						break;
					case 23:
						pixel->color = quitPtr[special_list[5]];
						special_list[5] += 1;
						break;
					case 24:
						pixel->color = selectPtr[num_counter[offsite]];
						num_counter[offsite] += 1;
						break;
					case 25:
						pixel->color = restartPtr[special_list[6]];
						special_list[6] += 1;
						break;
					case 26:
						pixel->color = losePtr[special_list[7]];
						special_list[7] += 1;
						break;
					case 27:
						pixel->color = winPtr[special_list[8]];
						special_list[8] += 1;
						break;
					case 28:
						pixel->color = authorPtr[special_list[9]];
						special_list[9] += 1;
						break;
					default:
						printf("you should never see this in the terminal,if so, fxxxxxk!");
					}
					pixel->x = x + 320;
					pixel->y = y + 180;
					drawPixel(pixel);
				}
				i++;
			}
		}
		for (int j = 0; j < 576; j++)
		{
			if (j < 10)
				special_list[j] = 0;
			num_counter[j] = 0; // 6 for live, 7 for score, 8 for time
		}
		i = 0;
		m = 0;

		if (flag)
			break;
	}

	/* free pixel's allocated memory */
	pthread_cancel(pid);
	pthread_cancel(t_id);
	pthread_cancel(m_id);
	pthread_cancel(lf_id);
	// pthread_join(pid, NULL);
	// pthread_join(t_id, NULL);
	// pthread_join(m_id, NULL);
	free(pixel);
	pixel = NULL;
	munmap(framebufferstruct.fptr, framebufferstruct.screenSize);

	return 0;
}

/* Draw a pixel */
void drawPixel(Pixel *pixel)
{
	long int location = (pixel->x + framebufferstruct.xOff) * (framebufferstruct.bits / 8) +
						(pixel->y + framebufferstruct.yOff) * framebufferstruct.lineLength;
	*((unsigned short int *)(framebufferstruct.fptr + location)) = pixel->color;
}

void *thread_function(void *ptr)
{
	// get gpio pointer
	unsigned int *gpioPtr = getGPIOPtr();

	// printf("pointer address: %p\n", gpioPtr);

	unsigned int *gpsel0 = gpioPtr;		// GPFSEL0
	unsigned int *gpsel1 = gpioPtr + 1; // GPFSEL1

	while (1)
	{
		Init_GPI(Latch, gpsel0, 1); // output
		Init_GPI(Data, gpsel1, 0);	// input
		Init_GPI(Clock, gpsel1, 1); // output

		Write_Clock(gpioPtr); // you can read the purpose of these code from name, I don't feel like I need to comment them
		Write_Latch(gpioPtr);

		Wait(12);

		Clear_Latch(gpioPtr);

		int *answer = Read_SNE(gpioPtr);

		if (win_flag == 1 || lose_flag == 1)
		{
			for (int i = 0; i < 16; i++)
			{
				if (*(answer + i) == 0)
				{
					player_postion.play_able = 0;
					player_postion.current_map = 0;
					game_map = map0;
					player_postion.x_pos = game_map.user_pos_x;
					player_postion.y_pos = game_map.user_pos_y;
					win_flag = 0;
					lose_flag = 0;
					player_postion.decision = 3;
					break;
				}
			}
			continue;
		}
		if (player_postion.play_able)
		{
			change_position(answer);
			if (*(answer + 3) == 0)
				Wait(100000);
		}
		else
		{
			change_menu(answer);
			if (*(answer + 3) == 0)
				Wait(100000);
		}
		if (flag)
		{
			break;
		}
		Wait(player_postion.speed);
	}
	return 0;
}

void change_position(int *ptr)
{

	if (*(ptr + 4) == 0)
	{
		if (player_postion.y_pos > 7)
		{
			int offsite = ((player_postion.y_pos - 8) / 40) * 32 + (player_postion.x_pos / 40);
			int up = game_map.map[offsite];
			if (up == 3) // coin
			{
				player_postion.y_pos -= 1;
				game_map.map[offsite] = 1; /// if touch a coin, make it disappear
				player_postion.score += 10 * 4;
			}
			else if (up == 1 || up == 18) // road, exit, special coin
			{
				player_postion.y_pos -= 1;
			}
			else if (up == 16)
				reset_player(0);
			else if (up == 5)
			{
				init_map(player_postion.current_map + 1);
			}
			else if (up == 17 || up == 19) // clear hidden door
				game_map.map[offsite] = 1;

		} // up
	}

	if (*(ptr + 5) == 0)
	{
		if (player_postion.y_pos < 711)
		{
			int offsite = ((player_postion.y_pos + 8) / 40) * 32 + (player_postion.x_pos / 40);
			int down = game_map.map[offsite];
			if (down == 3)
			{
				player_postion.y_pos += 1;
				game_map.map[offsite] = 1;
				player_postion.score += 10 * 5;
			}
			else if (down == 1 || down == 18)
			{
				player_postion.y_pos += 1;
			}
			else if (down == 16)
				reset_player(0);
			else if (down == 5)
			{
				init_map(player_postion.current_map + 1);
			}
			else if (down == 17 || down == 19) // clear hidden door
				game_map.map[offsite] = 1;

		} // down
	}

	if (*(ptr + 6) == 0)
	{
		if (player_postion.x_pos > 8)
		{
			int offsite = (player_postion.y_pos / 40) * 32 + ((player_postion.x_pos - 8) / 40);
			int left = game_map.map[offsite];
			if (left == 3)
			{
				player_postion.x_pos -= 1;
				game_map.map[offsite] = 1;
				player_postion.score += 10 * 6;
			}
			else if (left == 1 || left == 18)
			{
				player_postion.x_pos -= 1;
			}
			else if (left == 16)
				reset_player(0);
			else if (left == 5)
			{
				init_map(player_postion.current_map + 1);
			}
			else if (left == 17 || left == 19) // clear hidden door
				game_map.map[offsite] = 1;

		} // left
	}
	if (*(ptr + 7) == 0)
	{
		if (player_postion.x_pos < 1271)
		{
			int offsite = (player_postion.y_pos / 40) * 32 + ((player_postion.x_pos + 8) / 40);
			int right = game_map.map[offsite];
			if (right == 3)
			{
				player_postion.x_pos += 1;
				game_map.map[offsite] = 1;
				player_postion.score += 10 * 7;
			}
			else if (right == 1 || right == 18)
			{
				player_postion.x_pos += 1;
			}
			else if (right == 5)
			{
				init_map(player_postion.current_map + 1);
			}
			else if (right == 16)
				reset_player(0);
			else if (right == 17 || right == 19) // clear hidden door
				game_map.map[offsite] = 1;
			else if (right == 20)
			{
				player_postion.x_pos = game_map.user_pos_x + 40;
				player_postion.y_pos += 80;
				game_map.map[offsite] = 19;
			}
		} // right
	}

	if (*(ptr + 10) == 0)
	{ // speed down
		if (player_postion.speed + 10 <= player_postion.lower_bound)
			player_postion.speed += 10;
	}
	if (*(ptr + 11) == 0)
	{ // speed up
		if (player_postion.speed - 10 >= player_postion.upper_bound)
			player_postion.speed -= 10;
	}

	if (*(ptr + 3) == 0)
	{
		player_postion.time_flag = 0;
		player_postion.play_able = 0;
		resume_map = game_map;
		game_map = stop_page;
	}

	/*if (*(ptr + 2) == 0)
	{
		restart();
	}*/
}

void change_menu(int *ptr)
{
	if (*(ptr + 4) == 0)
	{
		player_postion.decision = 1;
		for (int i = 0; i < 32 * 18; i++)
		{
			if (game_map.map[i] == 22)
			{
				if (game_map.map[i + 1] != 22)
					game_map.map[i + 1] = 24;
			}
			if (game_map.map[i] == 25)
			{
				if (game_map.map[i + 1] != 25)
					game_map.map[i + 1] = 24;
			}
			if (game_map.map[i] == 23)
			{
				if (game_map.map[i + 1] != 23)
					game_map.map[i + 1] = 0;
			}
		}
	}
	else if (*(ptr + 5) == 0)
	{
		player_postion.decision = 2;
		for (int i = 0; i < 32 * 18; i++)
		{
			if (game_map.map[i] == 23)
			{
				if (game_map.map[i + 1] != 23)
					game_map.map[i + 1] = 24;
			}
			if (game_map.map[i] == 22)
			{
				if (game_map.map[i + 1] != 22)
					game_map.map[i + 1] = 0;
			}
			if (game_map.map[i] == 25)
			{
				if (game_map.map[i + 1] != 25)
					game_map.map[i + 1] = 0;
			}
		}
	}
	else if (*(ptr + 8) == 0)
	{
		if (player_postion.decision == 1)
		{
			restart();
		}
		else if (player_postion.decision == 2)
		{
			if (player_postion.current_map == 0)
				flag = 1;
			else
			{
				player_postion.current_map = 0;
				game_map = map0;
				player_postion.x_pos = game_map.user_pos_x;
				player_postion.y_pos = game_map.user_pos_y;
				win_flag = 0;
				lose_flag = 0;
				player_postion.decision = 3;
				Wait(100000);
			}
		}
	}
	else if (*(ptr + 3) == 0)
	{
		if (resume_map.map[0] != -1)
		{
			game_map = resume_map;
			player_postion.time_flag = 1;
			player_postion.play_able = 1;
		}
	}
}
void init_map(int theone)
{
	if (theone == 0)
	{
		player_postion.current_map = 0;
		player_postion.decision = 1; // one for start two for quit
		player_postion.play_able = 0;
		game_map = map0;
		player_postion.x_pos = game_map.user_pos_x;
		player_postion.y_pos = game_map.user_pos_y;
	}
	else if (theone == 1)
	{
		player_postion.play_able = 1;
		player_postion.current_map = 1;
		game_map = map1;
		player_postion.x_pos = game_map.user_pos_x;
		player_postion.y_pos = game_map.user_pos_y;
		player_postion.recent_time = player_postion.time;
	}
	else if (theone == 2)
	{
		player_postion.current_map = 2;
		game_map = map2;
		player_postion.x_pos = game_map.user_pos_x;
		player_postion.y_pos = game_map.user_pos_y;
		player_postion.time += 20;
		player_postion.recent_time = player_postion.time;
	}
	else if (theone == 3)
	{
		player_postion.current_map = 3;
		game_map = map3;
		player_postion.x_pos = game_map.user_pos_x;
		player_postion.y_pos = game_map.user_pos_y;
		player_postion.time += 20;
		player_postion.recent_time = player_postion.time;
	}
	else if (theone == 4)
	{
		player_postion.current_map = 4;
		game_map = map4;
		player_postion.x_pos = game_map.user_pos_x;
		player_postion.y_pos = game_map.user_pos_y;
		player_postion.time += 10;
		player_postion.recent_time = player_postion.time;
	}
	else if (theone >= 5)
	{
		player_postion.should_move = 0;
		player_postion.time_flag = 0;
		player_postion.score += (player_postion.time + player_postion.live * 33);
		for (int i = 0; i < 32 * 18; i++)
		{
			if (Formate[i] == 1)
				game_map.map[i] = 27;
		}
		win_flag = 1;
		Wait(100000);
	}
}

void set_number_color(int number, Pixel **p, int counter)
{ // handle 10 numbers
	if (number == 0)
	{
		short int *numberPtr = (short int *)zero.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 1)
	{
		short int *numberPtr = (short int *)one.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 2)
	{
		short int *numberPtr = (short int *)two.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 3)
	{
		short int *numberPtr = (short int *)three.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 4)
	{
		short int *numberPtr = (short int *)four.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 5)
	{
		short int *numberPtr = (short int *)five.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 6)
	{
		short int *numberPtr = (short int *)six.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 7)
	{
		short int *numberPtr = (short int *)seven.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 8)
	{
		short int *numberPtr = (short int *)eight.pixel_data;
		(*p)->color = numberPtr[counter];
	}
	else if (number == 9)
	{
		short int *numberPtr = (short int *)nine.pixel_data;
		(*p)->color = numberPtr[counter];
	}
}

void *timer(void *ptr)
{ // thread function for time
	clock_t pre = clock();
	clock_t aft;
	while (1)
	{
		while (player_postion.time_flag)
		{
			aft = clock();
			if ((float)((aft - pre) / CLOCKS_PER_SEC) >= 2.1f)
			{
				if (player_postion.time >= 1)
				{
					player_postion.time -= 1;
				}
				else
				{
					player_postion.should_move = 0;
					for (int i = 0; i < 32 * 18; i++)
					{
						if (Formate[i] == 1)
							game_map.map[i] = 26;
					}
					lose_flag = 1;
					player_postion.time_flag = 0;
				}
				pre = aft;
			}
		}
		if (flag)
			break;
	}
	return 0;
}

void *move_object_up_down()
{
	int direction = 0; // 0 for up,1 for down
	int checklist[32 * 18];
	for (int i = 0; i < (32 * 18); i++)
	{
		checklist[i] = 0;
	}
	while (1)
	{
		if (player_postion.should_move == 1)
		{
			for (int i = 0; i < (32 * 18); i++)
			{
				if (game_map.map[i] == 4 && checklist[i] == 0)
				{
					if (direction == 0) // up
					{
						if (game_map.map[i - 32] == 0)
						{
							direction = 1;
							break;
						}
						game_map.map[i] = 1;
						game_map.map[i - 32] = 4;
						checklist[i - 32] = 1;
					}
					else if (direction == 1) // down
					{
						if (game_map.map[i + 32] == 0)
						{
							direction = 0;
							break;
						}
						game_map.map[i] = 1;
						game_map.map[i + 32] = 4;
						checklist[i + 32] = 1;
					}
				}
			}
			for (int i = 0; i < (32 * 18); i++)
			{
				checklist[i] = 0;
			}
			Wait(40000);
		}
		if (flag)
			break;
	}
	return 0;
}

void *move_object_left_right()
{
	int direction = 0; // 0 for left,1 for right
	int checklist[32 * 18];
	for (int i = 0; i < (32 * 18); i++)
	{
		checklist[i] = 0;
	}
	while (1)
	{
		if (player_postion.should_move == 1)
		{
			for (int i = 0; i < (32 * 18); i++)
			{
				if (game_map.map[i] == 9 && checklist[i] == 0)
				{
					if (direction == 0) // left
					{
						if (game_map.map[i - 1] == 0)
						{
							direction = 1;
							break;
						}
						game_map.map[i] = 1;
						game_map.map[i - 1] = 9;
						checklist[i - 1] = 1;
					}
					else if (direction == 1) // right
					{
						if (game_map.map[i + 1] == 0)
						{
							direction = 0;
							break;
						}
						game_map.map[i] = 1;
						game_map.map[i + 1] = 9;
						checklist[i + 1] = 1;
					}
				}
			}
			for (int i = 0; i < (32 * 18); i++)
			{
				checklist[i] = 0;
			}
			Wait(40000);
		}
		if (flag)
			break;
	}
	return 0;
}

void reset_player(int key)
{
	player_postion.x_pos = game_map.user_pos_x;
	player_postion.y_pos = game_map.user_pos_y;
	if (key)
	{
		if (player_postion.live > 0)
			player_postion.live -= 1;
		if (player_postion.live == 0)
		{
			player_postion.should_move = 0;
			player_postion.time_flag = 0;
			for (int i = 0; i < 32 * 18; i++)
			{
				if (Formate[i] == 1)
					game_map.map[i] = 26;
			}
			lose_flag = 1;
			Wait(100000);
		}
	}
}

void restart()
{
	player_postion.x_width = 8;
	player_postion.y_width = 8;
	player_postion.live = 3;
	player_postion.time = 50;
	player_postion.score = 0;
	player_postion.time_flag = 1; // not start timer yet
	player_postion.speed = 600;
	player_postion.upper_bound = 600;
	player_postion.lower_bound = 1500;
	win_flag = 0;
	lose_flag = 0;
	player_postion.should_move = 1;
	init_map(1);
}