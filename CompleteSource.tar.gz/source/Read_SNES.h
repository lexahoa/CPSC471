#ifndef Read_SNES
#define Read_SNES

int *Read_SNE(unsigned int *gpioPtr);

#endif