#include <stdio.h>
#include "In_out.h"
#include "Read_SNES.h"

int *Read_SNE(unsigned int *gpioPtr)
{
    int *ptr;
    int result_array[16];
    ptr = &result_array[0]; // address for return
    for (int i = 0; i < 16; i++)
    {
        Wait(6);

        Clear_Clock(gpioPtr);

        Wait(6);

        result_array[i] = Read_Data(gpioPtr); // read a bit from DATA line
        /*if (i == 7)
        {
            printf("dada: %d\n", result_array[i]);
        }*/
        Write_Clock(gpioPtr); // set pin11 to 1  clock
    }
    return ptr;
}