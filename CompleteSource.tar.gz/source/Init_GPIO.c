#include <stdio.h>
#include "Init_GPIO.h"

void Init_GPI(int g , unsigned int* ptr, int mode){
    unsigned int value;

    if(mode == 1){  
        value = *ptr;
        value  = (value & ~(0b111<< ((g%10)*3) )) | ( 0b1<< ((g%10)*3) ); //output mode
        *ptr = value;
    }
    else if(mode == 0){
        value = *ptr;
        value  = (value & ~(0b111<< ((g%10)*3) ));  //input mode
        *ptr = value;
    }
}