1.there are hidden doors in the game, you can't tell the difference by looking(remember this)

2.there are normal value package and special package, special package will need some time before appear.
3.You can press Right to speed up and Left to speed down.
4.moving object will kill you, if more live remain, you will be transport to the beginning position of current map.
5.if time expires, no matter how many lives remain, you will lose.
6.the only way to win is reach the end of map4 with live remain. (In total there are 4 maps)
7.Remember you can slow down!!!
8.Green stuff is tree, trust me.
9.gray/black stuff is wall.
10.You won't die except you touch moving object, that's only way you will lose live.
11.Time,score and live will always be drawn on the screen during game,but the color of them are not very obvious to see.
12.if you keep holding controller right before Lose or Win, it's hard to see the prompt of Win or Lose
                                                            since you will directly go back to the main page 

13.basicly, the game screen will in the centre of monitor if you are using a 2K monitor (1920x1080), other wise no.
14.I don't have group mate, so author is just: zhongmin Ma AKA 'MZM'
15.special package could give you many benifit, like extra score,live, increase your speed limitation (press Right)
16.it's not hard to create a new map base on the code, but it's hard to understand the code.....


OS: Pi(Linux).
IDE: visual studio code. 